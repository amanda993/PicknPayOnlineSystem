
package com.PnP.RestController;

import com.PnP.Model.BankDetails;
import com.PnP.Service.BankingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Amanda
 */
@RestController
//@RestController a annotation that combine @Controller and @ResponseBody
//Controller control application logiv and act as a coordinator between view and model
//@Controller indicate this a MVC Spring
public class BankingController {
    
    @Autowired
//@Autowire -use annotation to get rid of the setter method for example  private Banktype banktype = new BanktypeImpl();
    BankingService bankService;
    //calling the service that is called BankService
    
    @RequestMapping(value="/banks",method=RequestMethod.POST)
    //@RequestMapping annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type.
    //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
    //using RequestMapping to get banks method from angular controller
    //
    public void placeBANK(@RequestBody BankDetails bankD){
        bankService.saveBank(bankD);
     // @RequestBody annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type
     //requesting placeBANK methohod 
    }
     
    @RequestMapping(method = RequestMethod.GET, value = "/pay",produces = {MediaType.APPLICATION_JSON_VALUE})
    //@RequestMapping annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type.
    //MediaType adds support for quality parameters as defined in the HTTP specification.
    public BankDetails accessBank(@RequestParam String bankType,String accNo, String pin) {
        //@RequestParam annotation which indicates that a method parameter should be bound to a web request parameter.
        return bankService.pay(bankType,accNo, pin);
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/bankdetails/{accNo}/{pin}")
    //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
    @ResponseBody
    // @RequestBody annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type
    public BankDetails accessBank(@PathVariable String accNo,@PathVariable String pin){
        return bankService.getBankData(accNo, pin);
    }
    
    
}
