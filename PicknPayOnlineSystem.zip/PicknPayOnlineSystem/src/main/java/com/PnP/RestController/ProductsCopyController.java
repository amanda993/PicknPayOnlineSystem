/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.PnP.RestController;

import com.PnP.Model.ProductsCopy;
import com.PnP.Service.ProductsCopyService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Amanda
 */
@RestController
//@RestController a annotation that combine @Controller and @ResponseBody
//Controller control application logiv and act as a coordinator between view and model
//@Controller indicate this a MVC Spring
public class ProductsCopyController {
    
    @Autowired
    //@Autowire -use annotation to get rid of the setter method for example  private Product product = new ProductImpl();
    private ProductsCopyService prodsCopyService;
    private List<ProductsCopy> prods; //Generic list
    
    @RequestMapping(value = "/productCopy", method = RequestMethod.GET)
    //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
     //mapping a method from angular controller
    public List<ProductsCopy> getAllCopies() //generit array
    {
        prods = new ArrayList<>();
        prodsCopyService.findAllproducts().forEach(prods::add);
        return prods;
    }  
    
    @RequestMapping(method = RequestMethod.POST,value = "/productCopy")
     //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
     //mapping a method from angular contro
    public void saveProductCopy(@RequestBody ProductsCopy productCopy)
    {
//@RequestBody annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type

        prodsCopyService.saveProductsCopy(productCopy);
    }
}
