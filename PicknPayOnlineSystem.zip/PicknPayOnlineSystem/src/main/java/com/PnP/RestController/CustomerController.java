/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.PnP.RestController;

import com.PnP.Model.Customers;
import com.PnP.Service.CustomerService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Amanda
 */
@RestController
//@RestController a annotation that combine @Controller and @ResponseBody
//Controller control application logiv and act as a coordinator between view and model
//@Controller indicate this a MVC Spring
public class CustomerController {
    
    @Autowired
    //@Autowire -use annotation to get rid of the setter method for example  private Banktype banktype = new BanktypeImpl();

    public  CustomerService custService;
   // calling the service that is called CustomerService

    public List<Customers> custAvailable = new ArrayList<>();
    // a list that has customer objects
    
    @RequestMapping(value="/register",method=RequestMethod.POST)
    //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
    public void registerCustomer(@RequestBody Customers cust,String registerStatus ){
        cust.setRole("customer");
         //@RequestBody annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type
        custService.addCustomer(cust);
        registerStatus = "Congradulations" + " " + cust.getFirstname() + " " + "You have successfully registered";
    }
    
    @RequestMapping(value="/login/user", produces ={MediaType.APPLICATION_JSON_VALUE})
    //@RequestMapping annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type.
    //MediaType adds support for quality parameters as defined in the HTTP specification.
    public Customers login(@RequestParam String username,String password ){
        return custService.login(username, password);
    }
    ////@RequestParam annotation which indicates that a method parameter should be bound to a web request parameter.
    
    @RequestMapping(value="/customers/all",method=RequestMethod.GET)
    //@RequestMapping annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type.
    //mapping a method from angular controller

    public List allCustomers(){ //method calling customers
        return custService.getCustomers();// returing a method from customer service method
    }
     @RequestMapping(method = RequestMethod.PUT, value = "/updateCust")
     //    //@RequestMapping annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type.

        public void updateCust(@RequestBody Customers cust)
         //@RequestBody annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type

        {
            System.out.println(cust.getcust_id());
//           geting the parametre
            custService.updateCust(cust);
           
        }
}
