
package com.PnP.RestController;

import com.PnP.Model.BankDetails;
import com.PnP.Model.CustomerOrder;
import com.PnP.Service.CustomersOrderService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Amanda
 */
@RestController
////@RestController a annotation that combine @Controller and @ResponseBody
//Controller control application logiv and act as a coordinator between view and model
//@Controller indicate this a MVC Spring
public class CustomerOrderController {
    
    
    @Autowired
     //@Autowire -use annotation to get rid of the setter method for example  private Banktype banktype = new BanktypeImpl();

    private CustomersOrderService customerOrderService;
    
    private List<CustomerOrder> customerOrdersList;
    //generic array
    //list of objects
    
    @RequestMapping(method = RequestMethod.POST,value = "/placeOrder")
       //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
      //mapping a method from angular controller
    public CustomerOrder saveOrder(@RequestBody CustomerOrder customerOrder)
     //@RequestBody annotations are used to bind the HTTP request/response body with a domain object in method parameter or return type
    {
        customerOrderService.saveCustomerOrder(customerOrder);// calling a method from customerOrderServices
        return customerOrder;
    }
    
  @RequestMapping(value="/customers/orders",method=RequestMethod.GET)
  //@RequestinMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
    public List allCustomers(){
        return customerOrderService.findAllcustomerOrders();// //list of objects
    }
}
