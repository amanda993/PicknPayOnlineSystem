/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.PnP.Model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Amanda
 */
@Entity
@Table(name = "customer_order")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomerOrder.findAll", query = "SELECT c FROM CustomerOrder c")
    , @NamedQuery(name = "CustomerOrder.findByOrderId", query = "SELECT c FROM CustomerOrder c WHERE c.orderId = :orderId")
    , @NamedQuery(name = "CustomerOrder.findByBankDetailId", query = "SELECT c FROM CustomerOrder c WHERE c.bankDetailId = :bankDetailId")
    , @NamedQuery(name = "CustomerOrder.findByCustId", query = "SELECT c FROM CustomerOrder c WHERE c.custId = :custId")
    , @NamedQuery(name = "CustomerOrder.findByOrderedDate", query = "SELECT c FROM CustomerOrder c WHERE c.orderedDate = :orderedDate")
    , @NamedQuery(name = "CustomerOrder.findByPrice", query = "SELECT c FROM CustomerOrder c WHERE c.price = :price")
    , @NamedQuery(name = "CustomerOrder.findByQuantity", query = "SELECT c FROM CustomerOrder c WHERE c.quantity = :quantity")
    , @NamedQuery(name = "CustomerOrder.findByStatus", query = "SELECT c FROM CustomerOrder c WHERE c.status = :status")
    
    
})
public class CustomerOrder implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "order_id")
    private Integer orderId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "bank_detail_id")
    private int bankDetailId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cust_id")
    private int custId;
    @Column(name = "ordered_date")
    @Temporal(TemporalType.DATE)
    private Date orderedDate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "price")
    private double price;
    @Basic(optional = false)
    @NotNull
    @Column(name = "quantity")
    private int quantity;
    @Size(max = 255)
    @Column(name = "status")
    private String status;
    
   
    

    public CustomerOrder() {
    }

    public CustomerOrder(Integer orderId) {
        this.orderId = orderId;
    }

    public CustomerOrder(Integer orderId, int bankDetailId, int custId, double price, int quantity) {
        this.orderId = orderId;
        this.bankDetailId = bankDetailId;
        this.custId = custId;
        this.price = price;
        this.quantity = quantity;
       
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public int getBankDetailId() {
        return bankDetailId;
    }

    public void setBankDetailId(int bankDetailId) {
        this.bankDetailId = bankDetailId;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public Date getOrderedDate() {
        return orderedDate;
    }

    public void setOrderedDate(Date orderedDate) {
        this.orderedDate = orderedDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }



    @Override
    public int hashCode() {
        int hash = 0;
        hash += (orderId != null ? orderId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomerOrder)) {
            return false;
        }
        CustomerOrder other = (CustomerOrder) object;
        if ((this.orderId == null && other.orderId != null) || (this.orderId != null && !this.orderId.equals(other.orderId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.Model.CustomerOrder[ orderId=" + orderId + " ]";
    }
    
}
