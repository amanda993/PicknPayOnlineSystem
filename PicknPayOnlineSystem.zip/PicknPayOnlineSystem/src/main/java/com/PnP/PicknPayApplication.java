package com.PnP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicknPayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicknPayApplication.class, args);
	}
}
