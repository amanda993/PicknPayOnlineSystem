/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.PnP.Repositories;

import com.PnP.Model.CustomerOrder;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author Amanda
 */
public interface CustomersOrderRepository extends CrudRepository<CustomerOrder, Integer>{
    
     
}
