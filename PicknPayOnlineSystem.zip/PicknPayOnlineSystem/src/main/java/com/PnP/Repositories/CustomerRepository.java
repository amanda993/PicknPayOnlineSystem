
package com.PnP.Repositories;

import com.PnP.Model.Customers;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author amanda
 */
public interface CustomerRepository extends CrudRepository<Customers,Integer>{
    @Query("SELECT c from Customers c where c.username = :username AND c.password = :password")
    // Query methods  that find information from the database and are declared on the repository interface
    public List<Customers> findByUsernameAndPassword(String Username ,String password );
    
    
    
    @Transactional
    //@Transaction allows to work with database transaction in declarative way
    @Modifying
    //@Modifying trigger query anntation to the method as updating quries instead of selecting one
    @Query("UPDATE Customers c SET c.email = :email , c.firstname = :firstname , c.lastname = :lastname  WHERE c.cust_id = :cust_id")
    // Query methods  that find information from the database and are declared on the repository interface
    public void updateCust(
                                @Param("cust_id") int cust_id,
                                @Param("email") String email,
                                @Param("firstname") String firstname,
                                @Param("lastname") String lastname
                              );
    //@param is a special format comment used by javadoc to generate documentation
    //description of the parameter (or parameters) a method can receive
}

