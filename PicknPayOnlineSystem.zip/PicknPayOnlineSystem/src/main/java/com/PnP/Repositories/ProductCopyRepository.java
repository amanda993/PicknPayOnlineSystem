
package com.PnP.Repositories;

import com.PnP.Model.ProductsCopy;
import java.io.Serializable;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author LebyanaWT
 */

public interface ProductCopyRepository extends CrudRepository<ProductsCopy, Integer>{
    
}
