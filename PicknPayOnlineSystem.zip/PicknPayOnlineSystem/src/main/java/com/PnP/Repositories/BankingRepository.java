
package com.PnP.Repositories;

import com.PnP.Model.BankDetails;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author amanda
 */
public interface BankingRepository extends CrudRepository<BankDetails, Long>{
    // interface class that extend CRUD to collect customer bankiing details
    @Query("SELECT b FROM BankDetails b WHERE b.accNo = :accNo AND  b.secretPin = :secretPin ")
    // mysql statement calling bankingDetails table from data and collecting data from it
    public BankDetails viewAccount(@Param(value = "accNo") String accountNo, @Param(value = "secretPin")String pin);
    // @Parma - send variable to the @Query annotation as parameters - identify by ':'
}
