package com.PnP.Service;

import com.PnP.Model.Customers;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;


public interface UserService {
    
	public Customers findUserByEmail(String email);
        //public String findIDByEmail(String email);
	public void saveUser(Customers user);
        public List<Customers> getAllCustomers();
        public Customers getCustomer(String cust_id);
        public void updateCust(Customers customers);
    
      
}
